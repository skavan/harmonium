"""Harmonium — instant-on remote frontend for Home Assistant.

The integration is the third leg of the Harmonium stack:

    yaml/ authoring model  →  compiled runtime config  →  engine (kiosk)

It owns the runtime config in HA storage, serves it over an
authenticated API, deploys it to the path the remotes read
(/local/remote-proto/config.json), and registers the Harmonium Studio
sidebar panel — the editor whose live preview is the engine itself in
#preview=1 mode.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from aiohttp import web

from homeassistant.components import frontend
from homeassistant.components.http import HomeAssistantView, StaticPathConfig
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

from .const import (
    DEPLOY_PATH,
    DOMAIN,
    PANEL_URL_PATH,
    STATIC_URL,
    STORAGE_KEY,
    STORAGE_VERSION,
)

_LOGGER = logging.getLogger(__name__)


def _read_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


class HarmoniumConfigView(HomeAssistantView):
    """Authenticated runtime-config endpoint for the Studio.

    GET  /api/harmonium/config          -> the stored runtime config
    POST /api/harmonium/config          -> validate, store, deploy
    """

    url = "/api/harmonium/config"
    name = "api:harmonium:config"
    requires_auth = True

    def __init__(self, hass: HomeAssistant, store: Store) -> None:
        self.hass = hass
        self.store = store

    async def get(self, request: web.Request) -> web.Response:
        data = await self.store.async_load()
        if data is None:
            return self.json_message("no config stored yet", status_code=404)
        return self.json(data)

    async def post(self, request: web.Request) -> web.Response:
        try:
            config = await request.json()
        except ValueError:
            return self.json_message("body is not valid JSON", status_code=400)

        problems = _validate(config)
        if problems:
            return self.json({"ok": False, "problems": problems}, status_code=422)

        await self.store.async_save(config)
        deploy = Path(self.hass.config.path(DEPLOY_PATH))
        await self.hass.async_add_executor_job(_write_json, deploy, config)
        _LOGGER.info("Harmonium config saved and deployed to %s", deploy)
        return self.json({"ok": True, "deployed": str(deploy)})


def _validate(config) -> list[str]:
    """Structural checks mirroring yaml/build_config.py's validate()."""
    problems: list[str] = []
    if not isinstance(config, dict):
        return ["config must be a JSON object"]
    screens = config.get("screens")
    if not isinstance(screens, dict) or not screens:
        return ["config.screens must be a non-empty object"]
    home = config.get("home_screen")
    if home not in screens:
        problems.append(f"home_screen '{home}' is not a screen")
    main_home = (config.get("global") or {}).get("main_home")
    if main_home and main_home not in screens:
        problems.append(f"global.main_home '{main_home}' is not a screen")
    for sid in config.get("screen_order") or []:
        if sid not in screens:
            problems.append(f"screen_order contains unknown screen '{sid}'")
    activities = config.get("activities") or {}
    for aid, activity in activities.items():
        target = (activity or {}).get("screen")
        if target and target not in screens:
            problems.append(f"activity '{aid}' references unknown screen '{target}'")
    for sid, screen in screens.items():
        parent = (screen or {}).get("parent")
        if parent and parent not in screens:
            problems.append(f"screen '{sid}' has unknown parent '{parent}'")
        groups = [screen.get("tiles") or []]
        groups += [s.get("tiles") or [] for s in screen.get("sections") or []]
        ids = [t.get("id") for g in groups for t in g]
        if any(i is None for i in ids):
            problems.append(f"screen '{sid}' has a tile without an id")
        if len(ids) != len(set(ids)):
            problems.append(f"screen '{sid}' has duplicate tile ids")
        for g in groups:
            for t in g:
                act = t.get("activity")
                if act and act not in activities:
                    problems.append(
                        f"screen '{sid}' tile '{t.get('id')}' references "
                        f"unknown activity '{act}'"
                    )
    return problems


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    store: Store = Store(hass, STORAGE_VERSION, STORAGE_KEY)

    # First run: seed the store from the currently deployed config so the
    # Studio opens showing exactly what the remotes are running.
    if await store.async_load() is None:
        deployed = Path(hass.config.path(DEPLOY_PATH))
        if deployed.exists():
            try:
                seeded = await hass.async_add_executor_job(_read_json, deployed)
                await store.async_save(seeded)
                _LOGGER.info("Seeded Harmonium store from %s", deployed)
            except (OSError, ValueError) as err:
                _LOGGER.warning("Could not seed from %s: %s", deployed, err)

    hass.http.register_view(HarmoniumConfigView(hass, store))

    studio = Path(__file__).parent / "studio"
    await hass.http.async_register_static_paths(
        [StaticPathConfig(STATIC_URL, str(studio), cache_headers=False)]
    )

    frontend.async_register_built_in_panel(
        hass,
        component_name="iframe",
        sidebar_title="Harmonium Studio",
        sidebar_icon="mdi:movie-edit-outline",
        frontend_url_path=PANEL_URL_PATH,
        config={"url": f"{STATIC_URL}/studio.html"},
        require_admin=True,
    )

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = store
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    frontend.async_remove_panel(hass, PANEL_URL_PATH)
    hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
    return True
